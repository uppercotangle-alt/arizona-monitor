"""Arizona RP API monitor."""
